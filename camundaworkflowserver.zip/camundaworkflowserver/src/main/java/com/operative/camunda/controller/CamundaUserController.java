package com.operative.camunda.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.operative.camunda.response.UserList;
import com.operative.camunda.service.CamundaUserService;
import com.operative.camunda.util.WorkflowConstants;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(tags = "userManagementController")
@RequestMapping(value = "/v1/{apiKey}/camunda")
@RestController
public class CamundaUserController {

  private static final Logger LOGGER = LoggerFactory.getLogger(CamundaUserController.class);

  @Autowired
  @Qualifier("camundaUserService")
  CamundaUserService camundaUserService;

  @ApiOperation(value = "Get Workflow users list")
  @ApiResponses(value = {
      @ApiResponse(code = 200, message = WorkflowConstants.HTTP_STATUS_CODE_200, response = String.class),
      @ApiResponse(code = 400, message = WorkflowConstants.HTTP_STATUS_CODE_400, response = String.class),
      @ApiResponse(code = 401, message = WorkflowConstants.HTTP_STATUS_CODE_401, response = String.class),
      @ApiResponse(code = 404, message = WorkflowConstants.HTTP_STATUS_CODE_404, response = String.class),
      @ApiResponse(code = 500, message = WorkflowConstants.HTTP_STATUS_CODE_500, response = String.class) })
  @GetMapping(value = "/userList", produces = MediaType.APPLICATION_JSON_VALUE)
  public List<UserList> getUsers() {
    LOGGER.info("UserController#Inside#{}", "getUsers");
    return camundaUserService.getUsers();
  }

}
