package com.operative.camunda.controller;

import java.io.File;
import java.io.FileInputStream;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.camunda.bpm.engine.RepositoryService;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.exception.NullValueException;
import org.camunda.bpm.engine.repository.Deployment;
import org.camunda.bpm.engine.repository.DeploymentBuilder;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.operative.camunda.response.WorkflowResponse;
import com.operative.camunda.serverconfig.WorkflowServiceConfig;
import com.operative.camunda.util.WorkflowConstants;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(tags = "workflowController")
@RequestMapping(value = "/v1/{apiKey}/camunda/workflow")
@RestController
public class CamundaWorkflowController {

  private static final Logger LOGGER = LoggerFactory.getLogger(CamundaWorkflowController.class);

  @Autowired
  @Qualifier("repositoryServices")
  private RepositoryService repositoryService;

  @Autowired
  @Qualifier(value = "runtimeService")
  RuntimeService runtimeService;

  @Autowired
  @Qualifier(value = "workflowServiceConfig")
  WorkflowServiceConfig workflowServiceConfig;

  @ApiOperation(value = "Deploy the workflow & activate process definition by Key")
  @ApiResponses(value = {
      @ApiResponse(code = 200, message = WorkflowConstants.HTTP_STATUS_CODE_200, response = String.class),
      @ApiResponse(code = 400, message = WorkflowConstants.HTTP_STATUS_CODE_400, response = String.class),
      @ApiResponse(code = 401, message = WorkflowConstants.HTTP_STATUS_CODE_401, response = String.class),
      @ApiResponse(code = 403, message = WorkflowConstants.HTTP_STATUS_CODE_403, response = String.class),
      @ApiResponse(code = 404, message = WorkflowConstants.HTTP_STATUS_CODE_404, response = String.class),
      @ApiResponse(code = 500, message = WorkflowConstants.HTTP_STATUS_CODE_500, response = String.class) })
  @GetMapping(value = "/deploy", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<WorkflowResponse> deployAndActivateProcessDefinitionByKey(
      @ApiParam(value = "processDefinitionKey", required = true) @RequestParam("processDefinitionKey") String processDefinitionKey) {
    LOGGER.info("Inside : {}", "deployAndActivateProcessDefinitionByKey");
    WorkflowResponse response = new WorkflowResponse();
    try {
      DeploymentBuilder builder = repositoryService.createDeployment().addInputStream("workflow.bpmn",
          new FileInputStream(new File("C:\\sts-3.9.1-workspace\\camundaserver\\src\\main\\resources\\workflow.bpmn")));
      LOGGER.info("DeploymentBuilder: {}", "builder");
      Deployment deployer = builder.deployWithResult();
      LOGGER.info("DeploymentTime : {} , deploymentId : {}", deployer.getDeploymentTime(), deployer.getId());
      repositoryService.activateProcessDefinitionByKey(processDefinitionKey, true, Calendar.getInstance().getTime());
      Map<String, String> resourceMap = workflowServiceConfig.getResourceDefinition(processDefinitionKey);
      response.setStatusCode("200");
      response.setStatusMessage("Workflow deployed and ProcessDefinition activated by key : " + processDefinitionKey);
      response.setProcessinstanceId(resourceMap.get("ProcessId"));
      response.setEventName(resourceMap.get("Name"));
    } catch (Exception e) {
      LOGGER.info("Exception {}", e);
    }
    return ResponseEntity.ok().body(response);
  }

  @ApiOperation(value = "Initiate the workflow process instance by processDefinitionKey")
  @ApiResponses(value = {
      @ApiResponse(code = 200, message = WorkflowConstants.HTTP_STATUS_CODE_200, response = String.class),
      @ApiResponse(code = 400, message = WorkflowConstants.HTTP_STATUS_CODE_400, response = String.class),
      @ApiResponse(code = 401, message = WorkflowConstants.HTTP_STATUS_CODE_401, response = String.class),
      @ApiResponse(code = 403, message = WorkflowConstants.HTTP_STATUS_CODE_403, response = String.class),
      @ApiResponse(code = 404, message = WorkflowConstants.HTTP_STATUS_CODE_404, response = String.class),
      @ApiResponse(code = 500, message = WorkflowConstants.HTTP_STATUS_CODE_500, response = String.class) })
  @GetMapping(value = "/initiate", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<WorkflowResponse> initiateWorkflow(
      @ApiParam(value = "processDefinitionKey", required = true) @RequestParam("processDefinitionKey") String processDefinitionKey,
      @ApiParam(value = "Avail ID", required = true) @RequestParam("availId") String businessKey) {
    LOGGER.info("WorkflowController#inside #{}", "initiateWorkflow");
    WorkflowResponse response = new WorkflowResponse();
    try {
      ProcessInstance processInstance = runtimeService.startProcessInstanceByKey(processDefinitionKey, businessKey);
      String eventname = workflowServiceConfig.getStartEventName(processDefinitionKey);
      LOGGER.info("WorkflowController#eventname#{}", eventname);
      LOGGER.info("WorkflowController#ProcessInstanceId#{}", processInstance.getProcessInstanceId());
      response.setStatusCode("200");
      response.setStatusMessage("Workflow process initiated");
      response.setProcessinstanceId(processInstance.getProcessInstanceId());
      response.setEventName(eventname);
      return ResponseEntity.ok().body(response);
    } catch (NullValueException nullValueException) {
      response.setStatusCode("204");
      response.setStatusMessage("No processes deployed with key: " + processDefinitionKey);
      response.setProcessinstanceId(null);
      response.setEventName(null);
      return ResponseEntity.ok().body(response);
    }
  }

  @ApiOperation(value = "Delete all the workflow processinstances")
  @ApiResponses(value = {
      @ApiResponse(code = 200, message = WorkflowConstants.HTTP_STATUS_CODE_200, response = String.class),
      @ApiResponse(code = 400, message = WorkflowConstants.HTTP_STATUS_CODE_400, response = String.class),
      @ApiResponse(code = 401, message = WorkflowConstants.HTTP_STATUS_CODE_401, response = String.class),
      @ApiResponse(code = 403, message = WorkflowConstants.HTTP_STATUS_CODE_403, response = String.class),
      @ApiResponse(code = 404, message = WorkflowConstants.HTTP_STATUS_CODE_404, response = String.class),
      @ApiResponse(code = 500, message = WorkflowConstants.HTTP_STATUS_CODE_500, response = String.class) })
  @DeleteMapping(value = "/deleteAllProcessInstances", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<WorkflowResponse> deleteAllProcessInstances(
      @ApiParam(value = "processDefinitionKey", required = true) @RequestParam("processDefinitionKey") String processDefinitionKey) {
    LOGGER.info("WorkflowController#inside {}", "deleteAllProcessInstances");
    WorkflowResponse response = new WorkflowResponse();
    try {
      List<ProcessInstance> processInstances = runtimeService.createProcessInstanceQuery().active().list();
      for (ProcessInstance instance : processInstances) {
        LOGGER.info("WorkflowController#Deleting process instance#{}", instance.getProcessInstanceId());
        runtimeService.deleteProcessInstance(instance.getProcessInstanceId(), "DeleteAllProcessInstances", true);
      }
      response.setStatusCode("200");
      response.setStatusMessage("Workflow Instance deleted");
      response.setProcessinstanceId("All");
      response.setEventName("Delete Instance");
      return ResponseEntity.ok().body(response);
    } catch (NullValueException nullValueException) {
      response.setStatusCode("204");
      response.setStatusMessage("No processes deployed with key : " + processDefinitionKey);
      response.setProcessinstanceId(null);
      response.setEventName(null);
      return ResponseEntity.ok().body(response);
    }
  }

  @ApiOperation(value = "Delete all the deployments and process instances")
  @ApiResponses(value = {
      @ApiResponse(code = 200, message = WorkflowConstants.HTTP_STATUS_CODE_200, response = String.class),
      @ApiResponse(code = 400, message = WorkflowConstants.HTTP_STATUS_CODE_400, response = String.class),
      @ApiResponse(code = 401, message = WorkflowConstants.HTTP_STATUS_CODE_401, response = String.class),
      @ApiResponse(code = 403, message = WorkflowConstants.HTTP_STATUS_CODE_403, response = String.class),
      @ApiResponse(code = 404, message = WorkflowConstants.HTTP_STATUS_CODE_404, response = String.class),
      @ApiResponse(code = 500, message = WorkflowConstants.HTTP_STATUS_CODE_500, response = String.class) })
  @DeleteMapping(value = "/deleteAllDeployments", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<WorkflowResponse> deleteAllDeployments() {
    LOGGER.info("WorkflowController#inside#{}", "deleteAllDeployments");
    WorkflowResponse response = new WorkflowResponse();
    try {
      List<Deployment> deploymentsList = repositoryService.createDeploymentQuery().list();
      for (Deployment deployment : deploymentsList) {
        LOGGER.info("WorkflowController#Deleting all Deployments#{}", deployment.getId());
        repositoryService.deleteDeployment(deployment.getId(), true, true);
      }
      response.setStatusCode("200");
      response.setStatusMessage("All deployments deleted");
      response.setProcessinstanceId("All");
      response.setEventName("Delete Deployment");
      return ResponseEntity.ok().body(response);
    } catch (NullValueException nullValueException) {
      response.setStatusCode("204");
      response.setStatusMessage("No processes deployed with key : ");
      response.setProcessinstanceId(null);
      response.setEventName(null);
      return ResponseEntity.ok().body(response);
    }
  }

  @ApiOperation(value = "Deletes the given deployment and cascade deletion to process instances, history process instances and jobs")
  @ApiResponses(value = {
      @ApiResponse(code = 200, message = WorkflowConstants.HTTP_STATUS_CODE_200, response = String.class),
      @ApiResponse(code = 400, message = WorkflowConstants.HTTP_STATUS_CODE_400, response = String.class),
      @ApiResponse(code = 401, message = WorkflowConstants.HTTP_STATUS_CODE_401, response = String.class),
      @ApiResponse(code = 403, message = WorkflowConstants.HTTP_STATUS_CODE_403, response = String.class),
      @ApiResponse(code = 404, message = WorkflowConstants.HTTP_STATUS_CODE_404, response = String.class),
      @ApiResponse(code = 500, message = WorkflowConstants.HTTP_STATUS_CODE_500, response = String.class) })
  @DeleteMapping(value = "/deleteDeploymentByID", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<WorkflowResponse> deleteDeploymentByID(
      @ApiParam(value = "deploymentKey", required = true) @RequestParam("deploymentKey") String deploymentId) {
    LOGGER.info("WorkflowController#inside#{}", "deleteDeploymentByID");
    WorkflowResponse response = new WorkflowResponse();
    try {
      LOGGER.info("WorkflowController#Deleting all Deployments#{}", deploymentId);
      repositoryService.deleteDeployment(deploymentId, true, true);
      response.setStatusCode("200");
      response.setStatusMessage("All deployments deleted");
      response.setProcessinstanceId("All");
      response.setEventName("Delete Deployment");
      return ResponseEntity.ok().body(response);
    } catch (NullValueException nullValueException) {
      response.setStatusCode("204");
      response.setStatusMessage("No process deployed with key : ");
      response.setProcessinstanceId(null);
      response.setEventName(null);
      return ResponseEntity.ok().body(response);
    }
  }

  @ApiOperation(value = "getResourceDefinition for process instance by processDefinitionKey")
  @ApiResponses(value = {
      @ApiResponse(code = 200, message = WorkflowConstants.HTTP_STATUS_CODE_200, response = String.class),
      @ApiResponse(code = 400, message = WorkflowConstants.HTTP_STATUS_CODE_400, response = String.class),
      @ApiResponse(code = 401, message = WorkflowConstants.HTTP_STATUS_CODE_401, response = String.class),
      @ApiResponse(code = 403, message = WorkflowConstants.HTTP_STATUS_CODE_403, response = String.class),
      @ApiResponse(code = 404, message = WorkflowConstants.HTTP_STATUS_CODE_404, response = String.class),
      @ApiResponse(code = 500, message = WorkflowConstants.HTTP_STATUS_CODE_500, response = String.class) })
  @GetMapping(value = "/resource", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<String> getResourceDefinition(
      @ApiParam(value = "processDefinitionKey", required = true) @RequestParam("processDefinitionKey") String processDefinitionKey) {
    JSONObject jsonObject = new JSONObject(workflowServiceConfig.getResourceDefinition(processDefinitionKey));
    return ResponseEntity.ok().body(jsonObject.toString());
  }

  public ResponseEntity<String> getProcessInstanceStatus() {
    return null;
  }

  public ResponseEntity<String> getCompletedProcessInstances() {
    return null;
  }

}
