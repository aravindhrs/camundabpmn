package com.operative.camunda.service;

public interface CamundaWorkflowService {

  public void deployAndActivateProcessDefinitionByKey();

  public void initiateWorkflow();

  public void deleteAllProcessInstances();

  public void deleteAllDeployments();

  public void getResourceDefinition();

}
