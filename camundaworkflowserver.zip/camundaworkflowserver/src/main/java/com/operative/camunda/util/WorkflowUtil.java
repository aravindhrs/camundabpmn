package com.operative.camunda.util;

import java.util.ArrayList;
import java.util.List;

import org.camunda.bpm.engine.identity.User;
import org.camunda.bpm.engine.task.Task;

import com.operative.camunda.response.UserList;
import com.operative.camunda.response.UserTasks;

public class WorkflowUtil {

  private WorkflowUtil() {

  }

  public static List<UserTasks> transformTaskToUserTasks(List<Task> taskList) {
    List<UserTasks> userTaskList = new ArrayList<>();
    for (Task task : taskList) {
      UserTasks userTasks = new UserTasks();
      userTasks.setId(task.getId());
      userTasks.setName(task.getName());
      userTasks.setDescription(task.getDescription());
      userTasks.setPriority(task.getPriority());
      userTasks.setOwner(task.getOwner());
      userTasks.setAssignee(task.getAssignee());
      userTasks.setProcessInstanceId(task.getProcessInstanceId());
      userTasks.setExecutionId(task.getExecutionId());
      userTasks.setProcessDefinitionId(task.getProcessDefinitionId());
      userTasks.setCaseDefinitionId(task.getCaseDefinitionId());
      userTasks.setCaseExecutionId(task.getCaseExecutionId());
      userTasks.setCaseInstanceId(task.getCaseInstanceId());
      userTasks.setTaskDefinitionKey(task.getTaskDefinitionKey());
      userTasks.setCreateTime(task.getCreateTime());
      userTasks.setDueDate(task.getDueDate());
      userTasks.setFollowUpDate(task.getFollowUpDate());
      userTasks.setParentTaskId(task.getParentTaskId());
      userTasks.setTenantId(task.getTenantId());
      userTaskList.add(userTasks);
    }
    return userTaskList;
  }

  public static List<UserList> createUserDto(List<User> users) {
    List<UserList> usersList = new ArrayList<>();
    for (User user : users) {
      UserList userList = new UserList();
      userList.setFirstName(user.getFirstName());
      userList.setLastName(user.getLastName());
      userList.setUserId(user.getId());
      userList.setEmail(user.getEmail());
      usersList.add(userList);
    }
    return usersList;
  }

}
