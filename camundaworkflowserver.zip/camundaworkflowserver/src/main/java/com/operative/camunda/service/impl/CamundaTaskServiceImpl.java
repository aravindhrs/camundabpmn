package com.operative.camunda.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.camunda.bpm.engine.RepositoryService;
import org.camunda.bpm.engine.TaskService;
import org.camunda.bpm.engine.task.Task;
import org.camunda.bpm.model.bpmn.instance.UserTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.operative.camunda.response.UserTasks;
import com.operative.camunda.service.CamundaTaskService;
import com.operative.camunda.util.WorkflowUtil;

@Service(value = "camundaTaskService")
public class CamundaTaskServiceImpl implements CamundaTaskService {

  private static final Logger LOGGER = LoggerFactory.getLogger(CamundaTaskServiceImpl.class);

  @Autowired
  @Qualifier(value = "taskService")
  private TaskService taskService;

  @Autowired
  @Qualifier("repositoryServices")
  private RepositoryService repositoryService;

  @Override
  public void completeUserTask(String processDefinitionKey, String processInstanceId, String businessKey,
      String assignee, String status) {
    List<Task> taskList = taskService.createTaskQuery().processInstanceBusinessKey(businessKey)
        .processDefinitionKey(processDefinitionKey).processInstanceId(processInstanceId).taskAssignee(assignee).list();
    LOGGER.info("{} -  Tasks assigned for user: {}", taskList.size(), assignee);
    Task task = taskList.get(0);
    LOGGER.info("TaskID: {}, Assignee: {}", task.getId(), task.getAssignee());
    final UserTask userTask = repositoryService.getBpmnModelInstance(task.getProcessDefinitionId())
        .getModelElementById(task.getTaskDefinitionKey());
    LOGGER.info("userTask TaskID: {}, userTask Assignee: {}", userTask.getId(), userTask.getCamundaAssignee());
    taskService.claim(task.getId(), task.getAssignee());
    Map<String, Object> variables = new HashMap<>();
    variables.put("approved", Boolean.valueOf(status));
    taskService.complete(task.getId(), variables);
  }

  @Override
  public void completeAllUserTask(String processDefinitionKey) {
    List<Task> taskList = taskService.createTaskQuery().list();
    for (Task task : taskList) {
      LOGGER.info("TaskID: {}, Assignee: {}", task.getId(), task.getAssignee());
      taskService.claim(task.getId(), task.getAssignee());
      taskService.complete(task.getId());
    }
  }

  @Override
  public long getUserTaskCount(String processDefinitionKey, String processInstanceId, String assignee) {
    long taskCount = 0;
    if (StringUtils.hasText(processInstanceId)) {
      taskCount = taskService.createTaskQuery().processDefinitionKey(processDefinitionKey)
          .processInstanceId(processInstanceId).taskAssignee(assignee).count();
    } else {
      taskCount = taskService.createTaskQuery().processDefinitionKey(processDefinitionKey).taskAssignee(assignee)
          .count();
    }
    return taskCount;
  }

  @Override
  public List<UserTasks> getAllTasksByUser(String assignee) {
    List<UserTasks> userTaskList = null;
    List<Task> taskList = taskService.createTaskQuery().taskAssignee(assignee).list();
    if (!CollectionUtils.isEmpty(taskList)) {
      userTaskList = WorkflowUtil.transformTaskToUserTasks(taskList);
    }
    return userTaskList;
  }

}
