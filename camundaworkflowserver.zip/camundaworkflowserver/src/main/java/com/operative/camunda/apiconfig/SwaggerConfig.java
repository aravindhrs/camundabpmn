package com.operative.camunda.apiconfig;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * Swagger configuration to visualize the REST API endpoints
 *
 * @author aravindhr
 * @date 17-May-2018
 *
 */

@EnableSwagger2
@Configuration
public class SwaggerConfig {

  @Value("${spring.application.name}")
  private String serviceId;

  ApiInfo apiInfo() {
    return new ApiInfoBuilder().title("Camunda Workflow").description("REST API endpoints for managing the Workflow")
        .license("Operative License")
        .licenseUrl("https://www.operative.com/operative-master-services-agreement-terms-conditions/")
        .termsOfServiceUrl("https://www.operative.com/operative-master-services-agreement-terms-conditions/")
        .version("1.0").contact(new Contact("Operative", "https://www.operative.com/", "workflowdev@sintecmedia.com"))
        .build();
  }

  @Bean
  public Docket customImplementation() {
    if (ELBConfig.elbExist()) {
      return new Docket(DocumentationType.SWAGGER_2).select()
          .apis(RequestHandlerSelectors.basePackage("com.operative.camunda")).paths(PathSelectors.any()).build()
          .host(ELBConfig.getElbHost()).pathMapping(getContextMapping())
          .directModelSubstitute(org.joda.time.LocalDate.class, java.sql.Date.class)
          .directModelSubstitute(org.joda.time.DateTime.class, java.util.Date.class).apiInfo(apiInfo())
          .useDefaultResponseMessages(false);
    }
    return new Docket(DocumentationType.SWAGGER_2).select()
        .apis(RequestHandlerSelectors.basePackage("com.operative.camunda")).paths(PathSelectors.any()).build()
        .directModelSubstitute(org.joda.time.LocalDate.class, java.sql.Date.class)
        .directModelSubstitute(org.joda.time.DateTime.class, java.util.Date.class).apiInfo(apiInfo())
        .useDefaultResponseMessages(false);
  }

  @Bean
  @Primary
  public ObjectMapper objectMapper(Jackson2ObjectMapperBuilder builder) {
    ObjectMapper objectMapper = builder.createXmlMapper(false).build();
    objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    return objectMapper;
  }

  private String getContextMapping() {
    return "/" + serviceId;
  }
}
