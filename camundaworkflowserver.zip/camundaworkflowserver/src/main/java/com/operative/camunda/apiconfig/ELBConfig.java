/*
 * Copyright (c) 2008 Operative. All Rights Reserved. THE AUTHOR MAKES NO
 * REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE
 * AUTHOR SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */
package com.operative.camunda.apiconfig;

import java.net.MalformedURLException;
import java.net.URL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Swagger requests will hit API Gateway with load balancing
 *
 * @author aravindhr
 * @date 17-May-2018
 */

@Component
public class ELBConfig {

  private ELBConfig() {
  }

  private static final Logger logger = LoggerFactory.getLogger(ELBConfig.class);

  private static final String API_GATEWAY_ELB = "api.gateway.elb";

  public static String getElbUrl(String urlStr) throws MalformedURLException {
    String apiGatewayElb = System.getProperty(API_GATEWAY_ELB);
    if (apiGatewayElb != null) {
      StringBuilder elbUrlResp = new StringBuilder();
      URL url = new URL(urlStr);
      elbUrlResp.append(apiGatewayElb).append(url.getPath());
      urlStr = elbUrlResp.toString();
    }
    return urlStr;
  }

  public static String getElbHost() {
    String apiGatewayElb = System.getProperty(API_GATEWAY_ELB);
    String host = null;
    if (apiGatewayElb != null) {
      try {
        URL url = new URL(apiGatewayElb);
        host = url.getHost();
      } catch (MalformedURLException e) {
        logger.error("Error while getting ELB Host", e);
      }
    }
    return host;
  }

  public static boolean elbExist() {
    String apiGatewayElb = System.getProperty(API_GATEWAY_ELB);
    return apiGatewayElb == null ? false : true;
  }

}
