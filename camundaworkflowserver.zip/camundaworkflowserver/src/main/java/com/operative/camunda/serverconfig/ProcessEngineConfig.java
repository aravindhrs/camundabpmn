package com.operative.camunda.serverconfig;

import javax.sql.DataSource;

import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.ProcessEngineConfiguration;
import org.camunda.bpm.engine.impl.history.HistoryLevel;
import org.camunda.bpm.engine.spring.ProcessEngineFactoryBean;
import org.camunda.bpm.engine.spring.SpringProcessEngineConfiguration;
import org.camunda.bpm.extension.reactor.CamundaReactor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

@Configuration(value = "processEngineConfig")
@DependsOn(value = "dataSourceConfig")
public class ProcessEngineConfig {

  private final Logger log = LoggerFactory.getLogger(getClass());

  @Value("classpath:workflow.bpmn")
  private Resource[] resources;

  @Autowired
  @Qualifier(value = "transactionManager")
  DataSourceTransactionManager dataSourceTransactionManager;

  @Autowired
  @Qualifier(value = "dataSource")
  DataSource dataSource;

  @Bean(name = "processEngineFactoryBean")
  public ProcessEngineFactoryBean processEngineFactoryBean() {
    ProcessEngineFactoryBean factoryBean = new ProcessEngineFactoryBean();
    factoryBean.setProcessEngineConfiguration(springProcessEngineConfiguration());
    return factoryBean;
  }

  @Bean(name = "processEngine")
  public ProcessEngine processEngine() {
    log.info("Initializing {}...", "SpringProcessEngine");
    return springProcessEngineConfiguration().buildProcessEngine();
  }

  public SpringProcessEngineConfiguration springProcessEngineConfiguration() {
    log.info("Calling {}...", "SpringProcessEngineConfiguration");
    SpringProcessEngineConfiguration processEngineConfig = new SpringProcessEngineConfiguration();

    processEngineConfig.setProcessEngineName("OperativeWorkflow");
    processEngineConfig.setDatabaseType("mysql");
    processEngineConfig.setDataSource(dataSource);
    processEngineConfig.setDatabaseSchemaUpdate("true");
    processEngineConfig.setTransactionManager(dataSourceTransactionManager);
    processEngineConfig.setHistory(ProcessEngineConfiguration.HISTORY_FULL);
    processEngineConfig.setHistoryLevel(HistoryLevel.HISTORY_LEVEL_FULL);
    processEngineConfig.setJpaHandleTransaction(true);
    processEngineConfig.setJpaCloseEntityManager(true);
    processEngineConfig.setJobExecutorActivate(false);
    processEngineConfig.setDeploymentName("OperativeWorkflow");
    processEngineConfig.setDeploymentSynchronized(true);
    processEngineConfig.setDeploymentResources(resources);
    processEngineConfig.getProcessEnginePlugins().add(CamundaReactor.plugin());
    log.info("Configuration for  {} completed...", "ProcessEngine");
    return processEngineConfig;
  }

}
