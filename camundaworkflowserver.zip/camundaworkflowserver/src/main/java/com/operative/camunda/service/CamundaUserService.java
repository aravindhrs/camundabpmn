package com.operative.camunda.service;

import java.util.List;

import com.operative.camunda.response.UserList;

public interface CamundaUserService {

  public List<UserList> getUsers();

}
