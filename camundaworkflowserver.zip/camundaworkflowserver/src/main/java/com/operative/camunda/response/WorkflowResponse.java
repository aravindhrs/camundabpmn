package com.operative.camunda.response;

public class WorkflowResponse {

  private String processinstanceId;
  private String eventName;
  private String statusCode;
  private String statusMessage;

  public String getEventName() {
    return eventName;
  }

  public void setEventName(String eventName) {
    this.eventName = eventName;
  }

  public String getStatusCode() {
    return statusCode;
  }

  public void setStatusCode(String statusCode) {
    this.statusCode = statusCode;
  }

  public String getStatusMessage() {
    return statusMessage;
  }

  public void setStatusMessage(String statusMessage) {
    this.statusMessage = statusMessage;
  }

  public String getProcessinstanceId() {
    return processinstanceId;
  }

  public void setProcessinstanceId(String processinstanceId) {
    this.processinstanceId = processinstanceId;
  }

}
