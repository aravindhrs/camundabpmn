package com.operative.camunda.service;

import java.util.List;

import com.operative.camunda.response.UserTasks;

public interface CamundaTaskService {

  void completeUserTask(String processDefinitionKey, String processInstanceId, String businessKey, String assignee,
      String status);

  void completeAllUserTask(String processDefinitionKey);

  long getUserTaskCount(String processDefinitionKey, String processInstanceId, String assignee);

  List<UserTasks> getAllTasksByUser(String assignee);
}
