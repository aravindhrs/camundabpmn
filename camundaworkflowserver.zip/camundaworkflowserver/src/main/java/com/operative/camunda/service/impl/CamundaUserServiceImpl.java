package com.operative.camunda.service.impl;

import java.util.List;

import org.camunda.bpm.engine.IdentityService;
import org.camunda.bpm.engine.identity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.operative.camunda.response.UserList;
import com.operative.camunda.service.CamundaUserService;
import com.operative.camunda.util.WorkflowUtil;

@Service(value = "camundaUserService")
public class CamundaUserServiceImpl implements CamundaUserService {

  @Autowired
  @Qualifier(value = "identityService")
  IdentityService identityService;

  @Override
  public List<UserList> getUsers() {
    List<User> users = identityService.createUserQuery().list();
    return WorkflowUtil.createUserDto(users);
  }

}
