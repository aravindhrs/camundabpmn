package com.operative.camunda;

import org.camunda.bpm.application.impl.ServletProcessApplication;
import org.camunda.bpm.engine.RepositoryService;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.DelegateTask;
import org.camunda.bpm.engine.delegate.ExecutionListener;
import org.camunda.bpm.engine.delegate.TaskListener;
import org.camunda.bpm.spring.boot.starter.annotation.EnableProcessApplication;
import org.camunda.bpm.spring.boot.starter.event.PostDeployEvent;
import org.camunda.bpm.spring.boot.starter.event.PreUndeployEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.event.EventListener;

import com.operative.camunda.serverconfig.DataSourceConfig;
import com.operative.camunda.serverconfig.ProcessEngineConfig;
import com.operative.camunda.serverconfig.WorkflowServiceConfig;

@EnableAutoConfiguration
@EnableProcessApplication
@SpringBootApplication(scanBasePackages = { "com.operative.camunda" })
@Import({ DataSourceConfig.class, ProcessEngineConfig.class, WorkflowServiceConfig.class })
@PropertySource(value = { "classpath:application.properties" })
public class CamundaServer extends ServletProcessApplication {

  private final Logger logger = LoggerFactory.getLogger(CamundaServer.class);

  @Autowired
  @Qualifier("repositoryServices")
  private RepositoryService repositoryService;

  @Autowired
  @Qualifier(value = "runtimeService")
  RuntimeService runtimeService;

  public static void main(String[] args) {
    SpringApplication.run(CamundaServer.class, args);
  }

  @EventListener
  private void processPostDeploy(PostDeployEvent event) {
    logger.info("Inside {} function", "processPostDeploy");
    runtimeService.activateProcessInstanceById("availsworkflow");
  }

  @EventListener
  public void onPreUndeploy(PreUndeployEvent event) {
    logger.info("Inside {} function", "onPreUndeploy");
  }

  @Bean(name = "taskListener")
  @Override
  public TaskListener getTaskListener() {
    return new TaskListener() {
      @Override
      public void notify(DelegateTask delegateTask) {
        System.out.println("TaskListener notifies.............");
      }
    };
  }

  @Override
  public ExecutionListener getExecutionListener() {
    return new ExecutionListener() {
      @Override
      public void notify(DelegateExecution execution) throws Exception {
        System.out.println("ExecutionListener notifies.............");
      }
    };
  }

}
