package com.operative.camunda.service.impl;

import org.camunda.bpm.engine.RepositoryService;
import org.camunda.bpm.engine.RuntimeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.operative.camunda.serverconfig.WorkflowServiceConfig;
import com.operative.camunda.service.CamundaWorkflowService;

@Service
public class CamundaWorkflowServiceImpl implements CamundaWorkflowService {

  private static final Logger LOGGER = LoggerFactory.getLogger(CamundaWorkflowServiceImpl.class);

  @Autowired
  @Qualifier("repositoryServices")
  private RepositoryService repositoryService;

  @Autowired
  @Qualifier(value = "runtimeService")
  private RuntimeService runtimeService;

  @Autowired
  @Qualifier(value = "workflowServiceConfig")
  private WorkflowServiceConfig workflowServiceConfig;

  @Override
  public void deployAndActivateProcessDefinitionByKey() {

  }

  @Override
  public void initiateWorkflow() {

  }

  @Override
  public void deleteAllProcessInstances() {

  }

  @Override
  public void deleteAllDeployments() {

  }

  @Override
  public void getResourceDefinition() {

  }

}
