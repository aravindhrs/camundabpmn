package com.operative.camunda.delegates;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component(value = "autoApprovalDelegate")
public class AutoApprovalDelegate implements JavaDelegate {

  private static final Logger LOGGER = LoggerFactory.getLogger(AutoApprovalDelegate.class);

  @Override
  public void execute(DelegateExecution execution) throws Exception {
    LOGGER.info("AutoApprovalDelegate Bean {} .....", "invoked");
    Thread.sleep(10000);
    LOGGER.info("Thread {} .....", "resumed the service task");
  }

}
