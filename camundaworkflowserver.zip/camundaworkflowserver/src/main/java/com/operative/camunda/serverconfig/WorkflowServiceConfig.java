package com.operative.camunda.serverconfig;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.camunda.bpm.engine.AuthorizationService;
import org.camunda.bpm.engine.CaseService;
import org.camunda.bpm.engine.DecisionService;
import org.camunda.bpm.engine.ExternalTaskService;
import org.camunda.bpm.engine.FilterService;
import org.camunda.bpm.engine.FormService;
import org.camunda.bpm.engine.HistoryService;
import org.camunda.bpm.engine.IdentityService;
import org.camunda.bpm.engine.ManagementService;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.RepositoryService;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.TaskService;
import org.camunda.bpm.engine.repository.ProcessDefinition;
import org.camunda.bpm.model.bpmn.BpmnModelInstance;
import org.camunda.bpm.model.bpmn.instance.StartEvent;
import org.camunda.bpm.model.bpmn.instance.UserTask;
import org.camunda.bpm.model.xml.Model;
import org.camunda.bpm.model.xml.type.ModelElementType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

@Configuration(value = "workflowServiceConfig")
@DependsOn(value = "processEngineConfig")
public class WorkflowServiceConfig {

  private static final Logger LOGGER = LoggerFactory.getLogger(WorkflowServiceConfig.class);

  @Autowired
  @Qualifier(value = "processEngine")
  ProcessEngine processEngine;

  RepositoryService repositoryService = null;

  @Bean(name = "repositoryServices")
  public RepositoryService repositoryService() {
    LOGGER.info("RepositoryService started.Calling {}......", "repositoryService");
    if (repositoryService == null) {
      LOGGER.info("RepositoryService {}.....", "invoked");
      repositoryService = processEngine.getRepositoryService();
    }
    return repositoryService;
  }

  @Bean(name = "runtimeService")
  public RuntimeService runtimeService() {
    return processEngine.getRuntimeService();
  }

  @Bean(name = "authorizationService")
  public AuthorizationService authorizationService() {
    return processEngine.getAuthorizationService();
  }

  @Bean(name = "caseService")
  public CaseService caseService() {
    return processEngine.getCaseService();
  }

  @Bean(name = "decisionService")
  public DecisionService decisionService() {
    return processEngine.getDecisionService();
  }

  @Bean(name = "taskService")
  public TaskService taskService() {
    return processEngine.getTaskService();
  }

  @Bean(name = "externalTaskService")
  public ExternalTaskService externalTaskService() {
    return processEngine.getExternalTaskService();
  }

  @Bean(name = "filterService")
  public FilterService filterService() {
    return processEngine.getFilterService();
  }

  @Bean(name = "formService")
  public FormService formService() {
    return processEngine.getFormService();
  }

  @Bean(name = "historyService")
  public HistoryService historyService() {
    return processEngine.getHistoryService();
  }

  @Bean(name = "identityService")
  public IdentityService identityService() {
    return processEngine.getIdentityService();
  }

  @Bean(name = "managementService")
  public ManagementService managementService() {
    return processEngine.getManagementService();
  }

  public String getStartEventName(String processDefinitionKey) {
    BpmnModelInstance modelInstance = getModelInstance(processDefinitionKey);
    return getStartEventName(modelInstance);
  }

  protected String getStartEventName(BpmnModelInstance modelInstance) {
    StartEvent startEvent = getStartEvent(modelInstance);
    return stripLineBreaks(startEvent.getName());
  }

  private String stripLineBreaks(String text) {
    return text.trim().replaceAll("\n", " ");
  }

  private BpmnModelInstance getModelInstance(String processDefinitionKey) {
    String processId = repositoryService.createProcessDefinitionQuery().processDefinitionKey(processDefinitionKey)
        .latestVersion().singleResult().getId();
    return repositoryService.getBpmnModelInstance(processId);
  }

  public String getUserTaskName(String processDefinitionKey) {
    BpmnModelInstance modelInstance = getModelInstance(processDefinitionKey);
    return getUserTaskName(modelInstance);
  }

  protected String getUserTaskName(BpmnModelInstance modelInstance) {
    StartEvent startEvent = getStartEvent(modelInstance);
    UserTask userTask = (UserTask) startEvent.getSucceedingNodes().singleResult();
    return stripLineBreaks(userTask.getName());
  }

  private StartEvent getStartEvent(BpmnModelInstance modelInstance) {
    ModelElementType startEventType = modelInstance.getModel().getType(StartEvent.class);
    return (StartEvent) modelInstance.getModelElementsByType(startEventType).iterator().next();
  }

  public Model getModel(String processDefinitionKey) {
    BpmnModelInstance modelInstance = getModelInstance(processDefinitionKey);
    return modelInstance.getModel();
  }

  public Map<String, String> getResourceDefinition(String processDefinitionKey) {
    Map<String, String> resourceDefinition = new HashMap<>();
    LOGGER.info("####processEngine name {}......", processEngine.getName());
    ProcessDefinition processDefinition = getProcessDefinition(processDefinitionKey);
    resourceDefinition.put("ProcessEngine", processEngine.getName());
    resourceDefinition.put("ProcessId", processDefinition.getId());
    resourceDefinition.put("Category", processDefinition.getCategory());
    resourceDefinition.put("DeploymentId", processDefinition.getDeploymentId());
    resourceDefinition.put("Description", processDefinition.getDescription());
    resourceDefinition.put("DiagramResourceName", processDefinition.getDiagramResourceName());
    resourceDefinition.put("Key", processDefinition.getKey());
    resourceDefinition.put("Name", processDefinition.getName());
    resourceDefinition.put("ResourceName", processDefinition.getResourceName());
    resourceDefinition.put("TenantId", processDefinition.getTenantId());
    resourceDefinition.put("VersionTag", processDefinition.getVersionTag());
    resourceDefinition.put("Version", String.valueOf(processDefinition.getVersion()));
    return resourceDefinition;
  }

  public ProcessDefinition getProcessDefinition(String processDefinitionKey) {
    return repositoryService.createProcessDefinitionQuery().processDefinitionKey(processDefinitionKey).latestVersion()
        .singleResult();
  }

  public List<ProcessDefinition> getProcessDefinitionList(String processDefinitionKey) {
    return repositoryService.createProcessDefinitionQuery().processDefinitionKey(processDefinitionKey)
        .orderByProcessDefinitionVersion().asc().list();
  }
}
