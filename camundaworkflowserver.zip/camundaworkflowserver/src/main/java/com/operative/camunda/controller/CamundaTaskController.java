package com.operative.camunda.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.operative.camunda.response.UserTasks;
import com.operative.camunda.response.WorkflowResponse;
import com.operative.camunda.service.CamundaTaskService;
import com.operative.camunda.util.WorkflowConstants;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(tags = "taskController")
@RequestMapping(value = "/v1/{apiKey}/camunda/tasks")
@RestController
public class CamundaTaskController {

  private static final Logger LOGGER = LoggerFactory.getLogger(CamundaTaskController.class);

  @Autowired
  @Qualifier("camundaTaskService")
  CamundaTaskService camundaTaskService;

  @ApiOperation(value = "Complete usertask by taskid assigned to the specific user")
  @ApiResponses(value = {
      @ApiResponse(code = 200, message = WorkflowConstants.HTTP_STATUS_CODE_200, response = String.class),
      @ApiResponse(code = 400, message = WorkflowConstants.HTTP_STATUS_CODE_400, response = String.class),
      @ApiResponse(code = 401, message = WorkflowConstants.HTTP_STATUS_CODE_401, response = String.class),
      @ApiResponse(code = 403, message = WorkflowConstants.HTTP_STATUS_CODE_403, response = String.class),
      @ApiResponse(code = 404, message = WorkflowConstants.HTTP_STATUS_CODE_404, response = String.class),
      @ApiResponse(code = 500, message = WorkflowConstants.HTTP_STATUS_CODE_500, response = String.class) })
  @GetMapping(value = "/complete", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<WorkflowResponse> completeUserTask(
      @ApiParam(value = "processDefinitionKey", required = true) @RequestParam("processDefinitionKey") String processDefinitionKey,
      @ApiParam(value = "processInstanceId", required = true) @RequestParam("processInstanceId") String processInstanceId,
      @ApiParam(value = "Avail Id", required = true) @RequestParam("availId") String businessKey,
      @ApiParam(value = "assignee", required = true) @RequestParam("assignee") String assignee,
      @ApiParam(value = "approvalstatus", required = true) @RequestParam("approvalstatus") String status) {
    LOGGER.info("TaskController#completeUserTask#processDefinitionKey : {}#processInstanceId  : {}#assignee : {}",
        processDefinitionKey, processInstanceId, assignee);
    camundaTaskService.completeUserTask(processDefinitionKey, processInstanceId, businessKey, assignee, status);
    WorkflowResponse response = new WorkflowResponse();
    response.setStatusCode("200");
    response.setStatusMessage("Task Completed");
    return ResponseEntity.ok().body(response);
  }

  @ApiOperation(value = "Complete all usertasks by taskid")
  @ApiResponses(value = {
      @ApiResponse(code = 200, message = WorkflowConstants.HTTP_STATUS_CODE_200, response = String.class),
      @ApiResponse(code = 400, message = WorkflowConstants.HTTP_STATUS_CODE_400, response = String.class),
      @ApiResponse(code = 401, message = WorkflowConstants.HTTP_STATUS_CODE_401, response = String.class),
      @ApiResponse(code = 403, message = WorkflowConstants.HTTP_STATUS_CODE_403, response = String.class),
      @ApiResponse(code = 404, message = WorkflowConstants.HTTP_STATUS_CODE_404, response = String.class),
      @ApiResponse(code = 500, message = WorkflowConstants.HTTP_STATUS_CODE_500, response = String.class) })
  @GetMapping(value = "/completeall", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<WorkflowResponse> completeAllUserTask(
      @ApiParam(value = "processDefinitionKey", required = true) @RequestParam("processDefinitionKey") String processDefinitionKey) {
    LOGGER.info("TaskController : {}", "completeUserTask");
    camundaTaskService.completeAllUserTask(processDefinitionKey);
    WorkflowResponse response = new WorkflowResponse();
    response.setStatusCode("200");
    response.setStatusMessage("All Tasks completed");
    return ResponseEntity.ok().body(response);
  }

  @ApiOperation(value = "Task counts assigned to the user for spec")
  @ApiResponses(value = {
      @ApiResponse(code = 200, message = WorkflowConstants.HTTP_STATUS_CODE_200, response = String.class),
      @ApiResponse(code = 400, message = WorkflowConstants.HTTP_STATUS_CODE_400, response = String.class),
      @ApiResponse(code = 401, message = WorkflowConstants.HTTP_STATUS_CODE_401, response = String.class),
      @ApiResponse(code = 403, message = WorkflowConstants.HTTP_STATUS_CODE_403, response = String.class),
      @ApiResponse(code = 404, message = WorkflowConstants.HTTP_STATUS_CODE_404, response = String.class),
      @ApiResponse(code = 500, message = WorkflowConstants.HTTP_STATUS_CODE_500, response = String.class) })
  @GetMapping(value = "/taskcount", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<String> getUserTaskCount(
      @ApiParam(value = "processDefinitionKey", required = true) @RequestParam("processDefinitionKey") String processDefinitionKey,
      @ApiParam(value = "processInstanceId", required = false) @RequestParam("processInstanceId") String processInstanceId,
      @ApiParam(value = "assignee", required = true) @RequestParam("assignee") String assignee) {
    LOGGER.info("TaskController: {}", "getUserTaskCount");
    String taskCountJson = null;
    long taskCount = camundaTaskService.getUserTaskCount(processDefinitionKey, processInstanceId, assignee);
    Map<String, String> countMap = new HashMap<>();
    countMap.put("count", String.valueOf(taskCount));
    ObjectMapper mapperObj = new ObjectMapper();
    try {
      taskCountJson = mapperObj.writeValueAsString(countMap);
      LOGGER.info("TaskCount: {}", taskCountJson);
    } catch (Exception e) {
      LOGGER.info("Exception: {}", e);
    }
    return ResponseEntity.ok().body(taskCountJson);
  }

  @ApiOperation(value = "Get all the tasks assigned to the user")
  @ApiResponses(value = {
      @ApiResponse(code = 200, message = WorkflowConstants.HTTP_STATUS_CODE_200, response = String.class),
      @ApiResponse(code = 400, message = WorkflowConstants.HTTP_STATUS_CODE_400, response = String.class),
      @ApiResponse(code = 401, message = WorkflowConstants.HTTP_STATUS_CODE_401, response = String.class),
      @ApiResponse(code = 403, message = WorkflowConstants.HTTP_STATUS_CODE_403, response = String.class),
      @ApiResponse(code = 404, message = WorkflowConstants.HTTP_STATUS_CODE_404, response = String.class),
      @ApiResponse(code = 500, message = WorkflowConstants.HTTP_STATUS_CODE_500, response = String.class) })
  @GetMapping(value = "/getAllTasksByUser", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<List<UserTasks>> getAllTasksByUser(
      @ApiParam(value = "assignee", required = true) @RequestParam("assignee") String assignee) {
    LOGGER.info("TaskController: {}", "getAllTasksByUser");
    List<UserTasks> userTaskList = null;
    try {
      if (StringUtils.hasText(assignee)) {
        LOGGER.info("TaskController#getAllTasksByUser#Assignee : {}", assignee);
        userTaskList = camundaTaskService.getAllTasksByUser(assignee);
      }
    } catch (Exception e) {
      LOGGER.info("Exception: {}", e);
    }
    return ResponseEntity.ok().body(userTaskList);
  }

}
