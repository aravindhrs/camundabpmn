package com.operative.camunda.serverconfig;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;

@Configuration(value = "dataSourceConfig")
public class DataSourceConfig {

  private static final Logger LOGGER = LoggerFactory.getLogger(DataSourceConfig.class);

  @Bean(name = "dataSource")
  public DataSource dataSource() {
    LOGGER.info("Inside {} configuration.....", "datasource");
    SimpleDriverDataSource dataSource = new SimpleDriverDataSource();
    try {
      dataSource.setDriver(com.mysql.jdbc.Driver.class.newInstance());
      dataSource.setUrl("jdbc:mysql://localhost:3306/camundadb?autoReconnect=true&useSSL=false");
      dataSource.setUsername("root");
      dataSource.setPassword("root");
    } catch (InstantiationException | IllegalAccessException e) {
      LOGGER.info("Exception: {} ", e);
    }
    return dataSource;
  }

  @Bean(name = "transactionManager")
  public DataSourceTransactionManager transactionManager() {
    LOGGER.info("Inside {} configuration.....", "transactionManager");
    return new DataSourceTransactionManager(dataSource());
  }
}
