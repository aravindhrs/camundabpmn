package com.operative.camunda.repository;

public interface UserRepository {

}
