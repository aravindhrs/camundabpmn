package com.operative.camunda.util;

public class WorkflowConstants {

  private WorkflowConstants() {
    throw new IllegalStateException("Instantiation not required for TemplateConstants.class");
  }

  public static final String AWSSERVICE = "export";
  public static final String SERVICEKEY = "export-aws";
  public static final String AWSDETAILS = "exportaws";
  public static final String ACCESSKEY = "awsaccesskey";
  public static final String SECRETKEY = "awssecretkey";
  public static final String REGION = "awsregion";
  public static final String VAULT = "Vault";
  public static final String VAULTERROR = "Vault is not configured correctly for AWS service.";

  public static final String HTTP_STATUS_CODE_100 = "Continue";
  public static final String HTTP_STATUS_CODE_101 = "Switching Protocols";
  public static final String HTTP_STATUS_CODE_102 = "Processing";
  public static final String HTTP_STATUS_CODE_200 = "OK";
  public static final String HTTP_STATUS_CODE_201 = "Created";
  public static final String HTTP_STATUS_CODE_202 = "Accepted";
  public static final String HTTP_STATUS_CODE_203 = "Non-Authoritative Information";
  public static final String HTTP_STATUS_CODE_204 = "No Content";
  public static final String HTTP_STATUS_CODE_205 = "Reset Content";
  public static final String HTTP_STATUS_CODE_206 = "Partial Content";
  public static final String HTTP_STATUS_CODE_207 = "Multi-Status";
  public static final String HTTP_STATUS_CODE_208 = "Already Reported";
  public static final String HTTP_STATUS_CODE_226 = "IM Used";
  public static final String HTTP_STATUS_CODE_300 = "Multiple Choices";
  public static final String HTTP_STATUS_CODE_301 = "Moved Permanently";
  public static final String HTTP_STATUS_CODE_302 = "Found";
  public static final String HTTP_STATUS_CODE_303 = "See Other";
  public static final String HTTP_STATUS_CODE_304 = "Not Modified";
  public static final String HTTP_STATUS_CODE_305 = "Use Proxy";
  public static final String HTTP_STATUS_CODE_306 = "(Unused)";
  public static final String HTTP_STATUS_CODE_307 = "Temporary Redirect";
  public static final String HTTP_STATUS_CODE_308 = "Permanent Redirect";
  public static final String HTTP_STATUS_CODE_400 = "Bad Request";
  public static final String HTTP_STATUS_CODE_401 = "Unauthorized";
  public static final String HTTP_STATUS_CODE_402 = "Payment Required";
  public static final String HTTP_STATUS_CODE_403 = "Forbidden";
  public static final String HTTP_STATUS_CODE_404 = "Not Found";
  public static final String HTTP_STATUS_CODE_405 = "Method Not Allowed";
  public static final String HTTP_STATUS_CODE_406 = "Not Acceptable";
  public static final String HTTP_STATUS_CODE_407 = "Proxy Authentication Required";
  public static final String HTTP_STATUS_CODE_408 = "Request Timeout";
  public static final String HTTP_STATUS_CODE_409 = "Conflict";
  public static final String HTTP_STATUS_CODE_410 = "Gone";
  public static final String HTTP_STATUS_CODE_411 = "Length Required";
  public static final String HTTP_STATUS_CODE_412 = "Precondition Failed";
  public static final String HTTP_STATUS_CODE_413 = "Request Entity Too Large";
  public static final String HTTP_STATUS_CODE_414 = "Request-URI Too Long";
  public static final String HTTP_STATUS_CODE_415 = "Unsupported Media Type";
  public static final String HTTP_STATUS_CODE_416 = "Requested Range Not Satisfiable";
  public static final String HTTP_STATUS_CODE_417 = "Expectation Failed";
  public static final String HTTP_STATUS_CODE_418 = "I'm a teapot (RFC 2324)";
  public static final String HTTP_STATUS_CODE_420 = "Enhance Your Calm";
  public static final String HTTP_STATUS_CODE_422 = "Unprocessable Entity";
  public static final String HTTP_STATUS_CODE_423 = "Locked";
  public static final String HTTP_STATUS_CODE_424 = "Failed Dependency";
  public static final String HTTP_STATUS_CODE_425 = "Reserved for WebDAV";
  public static final String HTTP_STATUS_CODE_426 = "Upgrade Required";
  public static final String HTTP_STATUS_CODE_428 = "Precondition Required";
  public static final String HTTP_STATUS_CODE_429 = "Too Many Requests";
  public static final String HTTP_STATUS_CODE_431 = "Request Header Fields Too Large";
  public static final String HTTP_STATUS_CODE_444 = "No Response";
  public static final String HTTP_STATUS_CODE_449 = "Retry With (Microsoft)";
  public static final String HTTP_STATUS_CODE_450 = "Blocked by Windows Parental Controls";
  public static final String HTTP_STATUS_CODE_451 = "Unavailable For Legal Reasons";
  public static final String HTTP_STATUS_CODE_499 = "Client Closed Request";
  public static final String HTTP_STATUS_CODE_500 = "Internal Server Error";
  public static final String HTTP_STATUS_CODE_501 = "Not Implemented";
  public static final String HTTP_STATUS_CODE_502 = "Bad Gateway";
  public static final String HTTP_STATUS_CODE_503 = "Service Unavailable";
  public static final String HTTP_STATUS_CODE_504 = "Gateway Timeout";
  public static final String HTTP_STATUS_CODE_505 = "HTTP Version Not Supported";
  public static final String HTTP_STATUS_CODE_506 = "Variant Also Negotiates";
  public static final String HTTP_STATUS_CODE_507 = "Insufficient Storage";
  public static final String HTTP_STATUS_CODE_508 = "Loop Detected";
  public static final String HTTP_STATUS_CODE_509 = "Bandwidth Limit Exceeded";
  public static final String HTTP_STATUS_CODE_510 = "Not Extended";
  public static final String HTTP_STATUS_CODE_511 = "Network Authentication Required";
  public static final String HTTP_STATUS_CODE_598 = "Network read timeout error";
  public static final String HTTP_STATUS_CODE_599 = "Network connect timeout error";
}
