package com.operative.camunda.delegates;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class EmailDelegate implements JavaDelegate {

  private static final Logger LOGGER = LoggerFactory.getLogger(EmailDelegate.class);

  @Override
  public void execute(DelegateExecution execution) throws Exception {
    LOGGER.info("EmailDelegate Bean {} .....", "invoked");
    LOGGER.info("EmailDelegate Bean {} .....", "invocation completed");
  }

}
